# EduMind AI

EduMind AI is a full-stack AI learning and project assistant built with FastAPI and vanilla HTML/CSS/JavaScript.

## Phase 1

This phase establishes the basic application foundation:
- FastAPI app with static file serving
- Home page at `/`
- Health endpoint at `/health`

## Run locally

```bash
python -m uvicorn app.main:app --reload --port 8000
```

Open http://localhost:8000
