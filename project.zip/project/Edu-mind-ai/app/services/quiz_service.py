"""Service for generating multiple-choice quizzes using OpenRouter."""

import json
from app.services.openrouter import OpenRouterService

QUIZ_GENERATOR_PROMPT = (
    "You are an expert academic test generator. Your task is to generate a high-quality, multiple-choice quiz "
    "specifically on the user's requested topic, matching the requested difficulty (Easy, Medium, Hard) and question count (5, 10, or 15).\n\n"
    "CRITICAL RULES:\n"
    "1. Topic Specificity: All questions MUST directly relate to the provided topic. Do not include questions from other subjects.\n"
    "2. Accuracy: Every question must be academically accurate and clear.\n"
    "3. Options Structure: Every question must have EXACTLY four options.\n"
    "4. Correct Answer: EXACTLY one option must be the correct answer. Identify it by its 0-indexed integer position (0 = first option, 1 = second, 2 = third, 3 = fourth).\n"
    "5. Format Constraint: Return ONLY valid raw JSON data. Do not wrap it in markdown code blocks like ```json ... ```. Do not output any notes, introductory explanations, or post-quiz commentary.\n\n"
    "REQUIRED JSON FORMAT:\n"
    "{\n"
    "  \"questions\": [\n"
    "    {\n"
    "      \"question\": \"Question text here?\",\n"
    "      \"options\": [\n"
    "        \"Option text A\",\n"
    "        \"Option text B\",\n"
    "        \"Option text C\",\n"
    "        \"Option text D\"\n"
    "      ],\n"
    "      \"correct_answer\": 0\n"
    "    }\n"
    "  ]\n"
    "}"
)


class QuizServiceError(Exception):
    """Raised when quiz generation fails."""


class QuizService:
    """Service for managing AI quiz generations."""

    def __init__(self) -> None:
        self.openrouter = OpenRouterService()

    async def generate_quiz(self, topic: str, difficulty: str, count: int) -> dict:
        """
        Generate multiple-choice quiz using OpenRouter.

        Args:
            topic: Topic string
            difficulty: Easy, Medium, or Hard
            count: 5, 10, or 15

        Returns:
            Dict containing parsed and validated questions list.
        """
        prompt_message = f"Topic: {topic}\nDifficulty: {difficulty}\nQuestion Count: {count}"

        try:
            raw_response = await self.openrouter.get_response_with_custom_prompt(
                prompt_message, QUIZ_GENERATOR_PROMPT
            )
        except Exception as exc:
            raise QuizServiceError(f"OpenRouter service failure: {str(exc)}") from exc

        # Strip markdown code blocks if the model wrapped it
        content = raw_response.strip()
        if content.startswith("```"):
            lines = content.splitlines()
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].startswith("```"):
                lines = lines[:-1]
            content = "\n".join(lines).strip()

        try:
            data = json.loads(content)
        except json.JSONDecodeError as exc:
            raise QuizServiceError("AI failed to return valid JSON.") from exc

        if not isinstance(data, dict) or "questions" not in data:
            raise QuizServiceError("AI JSON missing 'questions' root key.")

        questions = data["questions"]
        if not isinstance(questions, list):
            raise QuizServiceError("AI JSON 'questions' must be a list.")

        if len(questions) != count:
            raise QuizServiceError(
                f"AI generated {len(questions)} questions instead of requested {count}."
            )

        for idx, q in enumerate(questions):
            if not isinstance(q, dict):
                raise QuizServiceError(f"Question at index {idx} is not an object.")

            if "question" not in q or not isinstance(q["question"], str) or not q["question"].strip():
                raise QuizServiceError(f"Question at index {idx} has missing or empty question text.")

            if "options" not in q or not isinstance(q["options"], list) or len(q["options"]) != 4:
                raise QuizServiceError(f"Question at index {idx} must have exactly 4 options.")

            for opt_idx, opt in enumerate(q["options"]):
                if not isinstance(opt, str) or not opt.strip():
                    raise QuizServiceError(
                        f"Question at index {idx}, Option {opt_idx} is empty or not a string."
                    )

            if "correct_answer" not in q:
                raise QuizServiceError(f"Question at index {idx} is missing 'correct_answer'.")

            correct_val = q["correct_answer"]

            # Coerce string numbers if returned by model
            if isinstance(correct_val, str) and correct_val.isdigit():
                correct_val = int(correct_val)
                q["correct_answer"] = correct_val

            if not isinstance(correct_val, int) or correct_val < 0 or correct_val > 3:
                raise QuizServiceError(
                    f"Question at index {idx} has invalid correct_answer value: {correct_val}."
                )

        return data
