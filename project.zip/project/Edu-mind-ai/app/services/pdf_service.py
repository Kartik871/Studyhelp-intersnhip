"""PDF text extraction service using PyMuPDF and pytesseract OCR."""

import io
import os
import shutil
import platform
import fitz
from PIL import Image
import pytesseract
from pytesseract import TesseractNotFoundError

# Configure Tesseract path if running on Windows and not already in PATH
if platform.system() == "Windows":
    if not shutil.which("tesseract"):
        possible_paths = [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ]
        for path in possible_paths:
            if os.path.exists(path):
                pytesseract.pytesseract.tesseract_cmd = path
                break


class PDFServiceError(Exception):
    """Raised when PDF processing fails."""


class PDFService:
    """Service for extracting text from PDF files."""

    MAX_TEXT_LENGTH = 15000  # MVP limit to prevent excessive LLM context usage
    MAX_OCR_PAGES = 5        # Safe maximum page limit for OCR processing to prevent timeouts

    @staticmethod
    def extract_text(pdf_bytes: bytes) -> str:
        """
        Extract text from PDF bytes. Uses PyMuPDF text extraction,
        falling back to Tesseract OCR for scanned/image-only pages if needed.

        Args:
            pdf_bytes: Raw PDF file content as bytes

        Returns:
            Extracted text content

        Raises:
            PDFServiceError: If PDF cannot be processed or no text found
        """
        if not pdf_bytes:
            raise PDFServiceError("PDF file is empty")

        try:
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        except Exception as exc:
            raise PDFServiceError("Unable to open PDF file. The file may be corrupt.") from exc

        if doc.is_encrypted:
            doc.close()
            raise PDFServiceError("PDF is password-protected and cannot be processed")

        if doc.page_count == 0:
            doc.close()
            raise PDFServiceError("PDF contains no pages")

        extracted_pages = []
        total_text = ""

        # 1. Try PyMuPDF normal text extraction first
        for page_num in range(doc.page_count):
            try:
                page = doc.load_page(page_num)
                page_text = page.get_text()

                if page_text and page_text.strip():
                    # Normalize excessive whitespace
                    normalized_text = " ".join(page_text.split())
                    extracted_pages.append(normalized_text)
                    total_text += normalized_text + "\n\n"
            except Exception:
                # Skip problematic pages but continue
                continue

        # 2. Check if we extracted meaningful readable text (at least 20 letters)
        meaningful_char_count = sum(c.isalpha() for c in total_text)

        if meaningful_char_count >= 20:
            doc.close()
            if len(total_text) > PDFService.MAX_TEXT_LENGTH:
                total_text = total_text[: PDFService.MAX_TEXT_LENGTH] + "\n\n[Text truncated due to length limit]"
            return total_text.strip()

        # 3. OCR Fallback
        ocr_pages = []
        ocr_text = ""
        pages_to_ocr = min(doc.page_count, PDFService.MAX_OCR_PAGES)

        for page_num in range(pages_to_ocr):
            try:
                page = doc.load_page(page_num)
                # Render to 150 DPI image for OCR quality
                pix = page.get_pixmap(dpi=150)
                img_bytes = pix.tobytes("png")

                # Convert to Pillow Image
                img = Image.open(io.BytesIO(img_bytes))

                # Perform OCR
                try:
                    page_ocr_text = pytesseract.image_to_string(img)
                except TesseractNotFoundError as exc:
                    doc.close()
                    raise PDFServiceError(
                        "This PDF appears to be scanned. OCR support requires Tesseract OCR to be installed on the server."
                    ) from exc
                except Exception as exc:
                    if "tesseract is not installed or it's not in your PATH" in str(exc) or isinstance(exc, FileNotFoundError):
                        doc.close()
                        raise PDFServiceError(
                            "This PDF appears to be scanned. OCR support requires Tesseract OCR to be installed on the server."
                        ) from exc
                    doc.close()
                    raise PDFServiceError(f"OCR execution failure: {str(exc)}") from exc

                if page_ocr_text and page_ocr_text.strip():
                    normalized_text = " ".join(page_ocr_text.split())
                    ocr_pages.append(normalized_text)
                    ocr_text += normalized_text + "\n\n"
            except PDFServiceError:
                raise
            except Exception:
                continue

        doc.close()

        if not ocr_pages:
            raise PDFServiceError(
                "No readable text found in PDF. The PDF may be image-only or scanned without OCR."
            )

        if len(ocr_text) > PDFService.MAX_TEXT_LENGTH:
            ocr_text = ocr_text[: PDFService.MAX_TEXT_LENGTH] + "\n\n[Text truncated due to length limit]"

        return ocr_text.strip()
