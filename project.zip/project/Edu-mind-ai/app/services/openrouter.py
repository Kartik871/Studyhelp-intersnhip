import json
import os
from pathlib import Path
from typing import Any, AsyncIterator

import httpx
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[2]
ENV_PATH = BASE_DIR / ".env"
load_dotenv(dotenv_path=ENV_PATH, override=False)

OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = os.getenv("OPENROUTER_MODEL", "openai/gpt-4o-mini")

SYSTEM_PROMPT = (
    "You are EduMind AI, a helpful academic tutor for college students. "
    "Explain concepts clearly using simple language, provide examples when useful, "
    "and use structured explanations. When asked for exam-oriented answers, "
    "give concise, practical guidance. Avoid inventing facts and clearly state "
    "uncertainty when necessary."
)


class OpenRouterServiceError(Exception):
    """Raised when the OpenRouter API request fails."""


def _extract_text_chunk(payload: str) -> str | None:
    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        return None

    choices = event.get("choices", [])
    if not choices:
        return None

    delta = choices[0].get("delta", {}) if isinstance(choices[0], dict) else {}
    content = delta.get("content") if isinstance(delta, dict) else None

    if isinstance(content, str):
        return content

    return None


class OpenRouterService:
    def __init__(self, api_key: str | None = None, model: str | None = None) -> None:
        load_dotenv(dotenv_path=ENV_PATH, override=False)
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        self.model = model or os.getenv("OPENROUTER_MODEL") or DEFAULT_MODEL

    async def get_response(self, message: str) -> str:
        if not self.api_key:
            raise OpenRouterServiceError("Missing OPENROUTER_API_KEY")

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:8000",
            "X-Title": "EduMind AI",
        }

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": message},
            ],
            "temperature": 0.7,
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(OPENROUTER_API_URL, headers=headers, json=payload)
                response.raise_for_status()
                data = response.json()
        except httpx.TimeoutException as exc:
            raise OpenRouterServiceError("OpenRouter request timed out") from exc
        except httpx.HTTPStatusError as exc:
            raise OpenRouterServiceError(f"OpenRouter request failed: {exc.response.status_code}") from exc
        except httpx.RequestError as exc:
            raise OpenRouterServiceError("Unable to reach OpenRouter") from exc

        try:
            choices = data.get("choices", [])
            if not choices:
                raise OpenRouterServiceError("Invalid OpenRouter response")
            content = choices[0].get("message", {}).get("content", "")
            if isinstance(content, list):
                content = "".join(str(part.get("text", "")) for part in content if isinstance(part, dict))
            if not isinstance(content, str) or not content.strip():
                raise OpenRouterServiceError("Invalid OpenRouter response")
            return content.strip()
        except (AttributeError, TypeError, IndexError) as exc:
            raise OpenRouterServiceError("Invalid OpenRouter response") from exc

    async def get_response_with_custom_prompt(self, message: str, system_prompt: str) -> str:
        """Get response with a custom system prompt for specialized tasks."""
        if not self.api_key:
            raise OpenRouterServiceError("Missing OPENROUTER_API_KEY")

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:8000",
            "X-Title": "EduMind AI",
        }

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": message},
            ],
            "temperature": 0.7,
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(OPENROUTER_API_URL, headers=headers, json=payload)
                response.raise_for_status()
                data = response.json()
        except httpx.TimeoutException as exc:
            raise OpenRouterServiceError("OpenRouter request timed out") from exc
        except httpx.HTTPStatusError as exc:
            raise OpenRouterServiceError(f"OpenRouter request failed: {exc.response.status_code}") from exc
        except httpx.RequestError as exc:
            raise OpenRouterServiceError("Unable to reach OpenRouter") from exc

        try:
            choices = data.get("choices", [])
            if not choices:
                raise OpenRouterServiceError("Invalid OpenRouter response")
            content = choices[0].get("message", {}).get("content", "")
            if isinstance(content, list):
                content = "".join(str(part.get("text", "")) for part in content if isinstance(part, dict))
            if not isinstance(content, str) or not content.strip():
                raise OpenRouterServiceError("Invalid OpenRouter response")
            return content.strip()
        except (AttributeError, TypeError, IndexError) as exc:
            raise OpenRouterServiceError("Invalid OpenRouter response") from exc

    async def stream_response(self, message: str) -> AsyncIterator[str]:
        if not self.api_key:
            raise OpenRouterServiceError("Missing OPENROUTER_API_KEY")

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:8000",
            "X-Title": "EduMind AI",
        }

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": message},
            ],
            "temperature": 0.7,
            "stream": True,
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                async with client.stream("POST", OPENROUTER_API_URL, headers=headers, json=payload) as response:
                    response.raise_for_status()

                    saw_content = False
                    async for raw_line in response.aiter_lines():
                        if not raw_line:
                            continue

                        if not raw_line.startswith("data:"):
                            continue

                        data = raw_line[5:].strip()
                        if not data or data == "[DONE]":
                            continue

                        chunk = _extract_text_chunk(data)
                        if chunk is None:
                            continue

                        saw_content = True
                        yield chunk

                    if not saw_content:
                        raise OpenRouterServiceError("Invalid OpenRouter stream response")
        except httpx.TimeoutException as exc:
            raise OpenRouterServiceError("OpenRouter request timed out") from exc
        except httpx.HTTPStatusError as exc:
            raise OpenRouterServiceError(f"OpenRouter request failed: {exc.response.status_code}") from exc
        except httpx.RequestError as exc:
            raise OpenRouterServiceError("Unable to reach OpenRouter") from exc
