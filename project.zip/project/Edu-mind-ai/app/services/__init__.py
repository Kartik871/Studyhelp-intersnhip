"""Service layer for EduMind AI."""
