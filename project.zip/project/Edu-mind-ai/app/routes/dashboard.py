from fastapi import APIRouter
from pydantic import BaseModel
from app.database import get_dashboard_stats

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])

class StatsResponse(BaseModel):
    questions_asked: int
    notes_analyzed: int
    quizzes_taken: int
    average_score: int

@router.get("/stats", response_model=StatsResponse)
def get_stats() -> StatsResponse:
    stats = get_dashboard_stats()
    return StatsResponse(
        questions_asked=stats.get("questions_asked", 0),
        notes_analyzed=stats.get("notes_analyzed", 0),
        quizzes_taken=stats.get("quizzes_taken", 0),
        average_score=stats.get("average_score", 0)
    )
