from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
import logging

from app.services.openrouter import OpenRouterService, OpenRouterServiceError
from app.database import increment_questions_asked

logger = logging.getLogger("edumind.chat")

router = APIRouter(prefix="/api", tags=["chat"])


class ChatRequest(BaseModel):
    message: str = Field(..., description="User message")


class ChatResponse(BaseModel):
    response: str


@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest) -> ChatResponse:
    if not request.message or not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    try:
        increment_questions_asked()
    except Exception as exc:
        logger.error("Failed to increment questions_asked: %s", exc)

    try:
        service = OpenRouterService()
        response_text = await service.get_response(request.message.strip())
    except OpenRouterServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    return ChatResponse(response=response_text)


@router.post("/chat/stream")
async def chat_stream(request: ChatRequest) -> StreamingResponse:
    if not request.message or not request.message.strip():
        raise HTTPException(status_code=400, detail="Message cannot be empty")

    try:
        increment_questions_asked()
    except Exception as exc:
        logger.error("Failed to increment questions_asked in stream: %s", exc)

    async def event_stream() -> None:
        try:
            service = OpenRouterService()
            async for chunk in service.stream_response(request.message.strip()):
                yield chunk
        except OpenRouterServiceError:
            yield "\n\nSorry, I could not generate a reply right now."

    return StreamingResponse(
        event_stream(),
        media_type="text/plain",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )
