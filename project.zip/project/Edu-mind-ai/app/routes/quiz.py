"""Quiz generation API endpoints."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, field_validator
from app.services.quiz_service import QuizService, QuizServiceError
from app.database import record_quiz_result

router = APIRouter(prefix="/api/quiz", tags=["quiz"])


class QuizGenerateRequest(BaseModel):
    topic: str = Field(..., min_length=1, description="Topic of the quiz")
    difficulty: str = Field(..., description="Difficulty: Easy, Medium, or Hard")
    question_count: int = Field(..., description="Number of questions: 5, 10, or 15")

    @field_validator("topic")
    @classmethod
    def validate_topic(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Topic cannot be empty or blank space")
        return v.strip()

    @field_validator("difficulty")
    @classmethod
    def validate_difficulty(cls, v: str) -> str:
        if v not in ("Easy", "Medium", "Hard"):
            raise ValueError("Difficulty must be Easy, Medium, or Hard")
        return v

    @field_validator("question_count")
    @classmethod
    def validate_count(cls, v: int) -> int:
        if v not in (5, 10, 15):
            raise ValueError("Question count must be 5, 10, or 15")
        return v


class QuizQuestion(BaseModel):
    question: str
    options: list[str]
    correct_answer: int


class QuizGenerateResponse(BaseModel):
    questions: list[QuizQuestion]


@router.post("/generate", response_model=QuizGenerateResponse)
async def generate_quiz(request: QuizGenerateRequest) -> QuizGenerateResponse:
    """Generate multiple-choice quiz questions based on topic, difficulty, and count."""
    try:
        service = QuizService()
        data = await service.generate_quiz(
            topic=request.topic,
            difficulty=request.difficulty,
            count=request.question_count
        )
        return QuizGenerateResponse(questions=data["questions"])
    except QuizServiceError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


class QuizResultRequest(BaseModel):
    percentage: float = Field(..., description="Quiz score percentage (0 to 100)")

    @field_validator("percentage")
    @classmethod
    def validate_percentage(cls, v: float) -> float:
        if not (0 <= v <= 100):
            raise ValueError("Percentage must be between 0 and 100 inclusive")
        return v


@router.post("/result")
def post_quiz_result(request: QuizResultRequest) -> dict[str, str]:
    """Records a completed quiz result."""
    try:
        record_quiz_result(request.percentage)
        return {"status": "success"}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Database error occurred") from exc

