"""API routes for EduMind AI."""
