"""PDF analysis API endpoints."""

from fastapi import APIRouter, HTTPException, UploadFile, File
from pydantic import BaseModel
import logging

from app.services.pdf_service import PDFService, PDFServiceError
from app.services.openrouter import OpenRouterService, OpenRouterServiceError
from app.database import increment_notes_analyzed

logger = logging.getLogger("edumind.pdf")


router = APIRouter(prefix="/api/pdf", tags=["pdf"])

NOTES_SUMMARIZATION_PROMPT = (
    "You are an expert academic note summarizer for college students. "
    "Your task is to analyze the provided study notes and create a structured summary. "
    "Use clear academic language suitable for university-level education. "
    "Preserve important technical facts and definitions accurately. "
    "Avoid inventing information not present in the notes. "
    "Clearly state when information is unclear or ambiguous. "
    "Use bullet points where useful for readability. "
    "Structure your response using Markdown with these exact headings:\n\n"
    "## Overview\n\n"
    "## Key Concepts\n\n"
    "## Important Points\n\n"
    "## Important Definitions\n\n"
    "## Exam-Focused Takeaways\n\n"
    "Ensure each section contains relevant, accurate content from the notes."
)


class PDFAnalysisResponse(BaseModel):
    summary: str


@router.post("/analyze", response_model=PDFAnalysisResponse)
async def analyze_pdf(file: UploadFile = File(...)) -> PDFAnalysisResponse:
    """Analyze a PDF file and generate an AI-powered notes summary."""
    if not file:
        raise HTTPException(status_code=400, detail="No file provided")

    # Validate filename
    filename = file.filename or ""
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="File must be a PDF")

    # Validate content type if available
    if file.content_type and file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="File must be a PDF")

    # Read file content
    file_content = await file.read()

    # Validate file size (10 MB limit)
    max_size = 10 * 1024 * 1024
    if len(file_content) > max_size:
        raise HTTPException(status_code=400, detail="PDF file size must be 10 MB or less")

    if len(file_content) == 0:
        raise HTTPException(status_code=400, detail="PDF file is empty")

    # Extract text from PDF
    try:
        pdf_service = PDFService()
        extracted_text = pdf_service.extract_text(file_content)
    except PDFServiceError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Generate AI summary using OpenRouter
    try:
        openrouter_service = OpenRouterService()
        summary = await openrouter_service.get_response_with_custom_prompt(
            extracted_text, NOTES_SUMMARIZATION_PROMPT
        )
    except OpenRouterServiceError as exc:
        raise HTTPException(status_code=502, detail=f"AI summarization failed: {str(exc)}") from exc

    try:
        increment_notes_analyzed()
    except Exception as exc:
        logger.error("Failed to increment notes_analyzed: %s", exc)

    return PDFAnalysisResponse(summary=summary)

