"""EduMind AI application package."""
