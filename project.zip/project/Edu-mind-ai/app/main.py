from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.routes.chat import router as chat_router
from app.routes.pdf import router as pdf_router
from app.routes.quiz import router as quiz_router
from app.routes.dashboard import router as dashboard_router
from app.database import initialize_database

load_dotenv()

app = FastAPI(title="EduMind AI", version="0.1.0")

@app.on_event("startup")
def on_startup() -> None:
    initialize_database()

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.include_router(chat_router)
app.include_router(pdf_router)
app.include_router(quiz_router)
app.include_router(dashboard_router)


@app.get("/")
def read_index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
