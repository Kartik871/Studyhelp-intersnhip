function initializeApp() {
  const navItems = document.querySelectorAll('.nav-item');
  const sections = document.querySelectorAll('.page-section');
  const pageTitle = document.getElementById('pageTitle');
  const mobileToggle = document.getElementById('mobileToggle');
  const sidebar = document.getElementById('sidebar');
  const chatMessages = document.getElementById('chatMessages');
  const chatInput = document.getElementById('chatInput');
  const sendBtn = document.getElementById('sendBtn');
  const clearChatBtn = document.getElementById('clearChatBtn');
  const chatWindow = document.getElementById('chatWindow');
  const pdfUploadZone = document.getElementById('pdfUploadZone');
  const pdfFileInput = document.getElementById('pdfFileInput');
  const browsePdfBtn = document.getElementById('browsePdfBtn');
  const removePdfBtn = document.getElementById('removePdfBtn');
  const analyzePdfBtn = document.getElementById('analyzePdfBtn');
  const selectedFileCard = document.getElementById('selectedFileCard');
  const selectedFileName = document.getElementById('selectedFileName');
  const selectedFileSize = document.getElementById('selectedFileSize');
  const pdfError = document.getElementById('pdfError');
  const analysisResult = document.getElementById('analysisResult');
  const analysisBody = document.getElementById('analysisBody');
  let isStreaming = false;
  let selectedPdfFile = null;
  let isAnalyzingPdf = false;
  let quizResultRecorded = false;

  async function fetchAndPopulateStats() {
    try {
      const response = await fetch('/api/dashboard/stats');
      if (response.ok) {
        const stats = await response.json();
        const questionsAskedEl = document.getElementById('stat-questions-asked');
        const notesAnalyzedEl = document.getElementById('stat-notes-analyzed');
        const quizzesTakenEl = document.getElementById('stat-quizzes-taken');
        const averageScoreEl = document.getElementById('stat-average-score');

        if (questionsAskedEl) questionsAskedEl.textContent = stats.questions_asked;
        if (notesAnalyzedEl) notesAnalyzedEl.textContent = stats.notes_analyzed;
        if (quizzesTakenEl) quizzesTakenEl.textContent = stats.quizzes_taken;
        if (averageScoreEl) averageScoreEl.textContent = `${stats.average_score}%`;
      }
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error);
    }
  }

  const sectionTitles = {
    dashboard: 'Dashboard',
    'ai-tutor': 'AI Tutor',
    'pdf-analyzer': 'PDF Analyzer',
    'quiz-generator': 'Quiz Generator'
  };

  const initialTutorMessage = {
    role: 'assistant',
    text: "Hi! I'm your EduMind AI Tutor. Ask me any academic question and I'll help you understand it clearly."
  };

  function formatFileSize(size) {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  }

  function showPdfError(message) {
    if (!pdfError) return;
    pdfError.textContent = message;
    pdfError.hidden = false;
  }

  function clearPdfError() {
    if (!pdfError) return;
    pdfError.textContent = '';
    pdfError.hidden = true;
  }

  function resetPdfAnalysisResult() {
    if (analysisResult) {
      analysisResult.hidden = true;
    }
    if (analysisBody) {
      analysisBody.innerHTML = '';
    }
  }

  function updateAnalyzeButton() {
    if (!analyzePdfBtn) return;
    analyzePdfBtn.disabled = !selectedPdfFile || isAnalyzingPdf;
  }

  function renderSelectedFile(file) {
    if (!selectedFileCard || !selectedFileName || !selectedFileSize) return;
    selectedFileName.textContent = file.name;
    selectedFileSize.textContent = formatFileSize(file.size);
    selectedFileCard.hidden = false;
  }

  function clearSelectedFile() {
    selectedPdfFile = null;
    if (selectedFileCard) {
      selectedFileCard.hidden = true;
    }
    if (selectedFileName) {
      selectedFileName.textContent = '';
    }
    if (selectedFileSize) {
      selectedFileSize.textContent = '';
    }
    clearPdfError();
    resetPdfAnalysisResult();
    updateAnalyzeButton();
  }

  function validatePdfFile(file) {
    if (!file) {
      return { valid: false, message: 'Please select a PDF file.' };
    }

    const name = file.name.toLowerCase();
    if (!name.endsWith('.pdf')) {
      return { valid: false, message: 'Please select a PDF file.' };
    }

    if (file.size > 10 * 1024 * 1024) {
      return { valid: false, message: 'PDF file size must be 10 MB or less.' };
    }

    if (file.type && file.type !== '' && file.type !== 'application/pdf') {
      return { valid: false, message: 'Please select a PDF file.' };
    }

    return { valid: true };
  }

  function handlePdfSelection(file) {
    const validation = validatePdfFile(file);
    if (!validation.valid) {
      selectedPdfFile = null;
      if (selectedFileCard) {
        selectedFileCard.hidden = true;
      }
      showPdfError(validation.message);
      resetPdfAnalysisResult();
      updateAnalyzeButton();
      return;
    }

    selectedPdfFile = file;
    clearPdfError();
    renderSelectedFile(file);
    resetPdfAnalysisResult();
    updateAnalyzeButton();
  }

  function activateSection(targetId) {
    sections.forEach((section) => {
      section.classList.toggle('active', section.id === targetId);
    });

    navItems.forEach((item) => {
      item.classList.toggle('active', item.dataset.target === targetId);
    });

    if (pageTitle) {
      pageTitle.textContent = sectionTitles[targetId] || 'Dashboard';
    }
  }

  function renderMarkdownToHtml(text) {
    if (!text) return '';

    const parsed = typeof marked !== 'undefined'
      ? marked.parse(text, { gfm: true, breaks: true })
      : text;
    const html = typeof parsed === 'string' ? parsed : String(parsed);

    return typeof DOMPurify !== 'undefined'
      ? DOMPurify.sanitize(html, { USE_PROFILES: { html: true } })
      : html;
  }

  function createMessageBubble(text, role, renderMarkdown = false) {
    const bubble = document.createElement('div');
    bubble.className = `message-bubble ${role}`;

    if (role === 'assistant' && renderMarkdown) {
      bubble.innerHTML = renderMarkdownToHtml(text);
    } else {
      bubble.textContent = text;
    }

    return bubble;
  }

  function renderWelcomeMessage() {
    if (!chatMessages) return;
    chatMessages.innerHTML = '';
    chatMessages.appendChild(createMessageBubble(initialTutorMessage.text, initialTutorMessage.role, false));
    scrollChatToBottom();
  }

  function scrollChatToBottom() {
    if (chatWindow) {
      chatWindow.scrollTop = chatWindow.scrollHeight;
    }
  }

  function updateComposerState() {
    if (!chatInput || !sendBtn) return;
    const isEmpty = chatInput.value.trim() === '';
    sendBtn.disabled = isEmpty || isStreaming;
    chatInput.disabled = isStreaming;
  }

  function autoResizeTextarea() {
    if (!chatInput) return;
    chatInput.style.height = 'auto';
    const maxHeight = 140;
    chatInput.style.height = `${Math.min(chatInput.scrollHeight, maxHeight)}px`;
  }

  function showTypingIndicator() {
    if (!chatMessages) return;
    const typing = document.createElement('div');
    typing.className = 'typing-indicator';
    typing.innerHTML = '<span></span><span></span><span></span>';
    chatMessages.appendChild(typing);
    scrollChatToBottom();
    return typing;
  }

  async function handleSendMessage() {
    if (!chatInput || !chatMessages || isStreaming) return;

    const text = chatInput.value.trim();
    if (!text) return;

    isStreaming = true;
    updateComposerState();

    chatMessages.appendChild(createMessageBubble(text, 'user', false));
    chatInput.value = '';
    autoResizeTextarea();
    scrollChatToBottom();

    const typingIndicator = showTypingIndicator();
    const assistantBubble = createMessageBubble('', 'assistant', true);
    chatMessages.appendChild(assistantBubble);
    scrollChatToBottom();

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: text })
      });

      if (!response.ok || !response.body) {
        throw new Error('Unable to read streamed response');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        if (!chunk) continue;

        accumulated += chunk;
        assistantBubble.innerHTML = renderMarkdownToHtml(accumulated);
        scrollChatToBottom();
      }

      const finalChunk = decoder.decode();
      if (finalChunk) {
        accumulated += finalChunk;
        assistantBubble.innerHTML = renderMarkdownToHtml(accumulated);
      }

      if (!accumulated.trim()) {
        assistantBubble.innerHTML = renderMarkdownToHtml('Sorry, I could not generate a reply right now.');
      }

      fetchAndPopulateStats();
    } catch (error) {
      assistantBubble.innerHTML = renderMarkdownToHtml('Sorry, I could not reach the tutor service right now.');
    } finally {
      if (typingIndicator && typingIndicator.parentNode) {
        typingIndicator.remove();
      }

      isStreaming = false;
      updateComposerState();
      chatInput.focus();
      scrollChatToBottom();
    }
  }

  navItems.forEach((item) => {
    item.addEventListener('click', () => {
      activateSection(item.dataset.target);

      if (window.innerWidth <= 760 && sidebar) {
        sidebar.classList.remove('is-open');
        document.body.classList.remove('sidebar-open');
      }
    });
  });

  document.querySelectorAll('.action-btn').forEach((button) => {
    const targetId = button.dataset.target;
    if (!targetId) return;

    button.addEventListener('click', () => {
      activateSection(targetId);
      if (window.innerWidth <= 760 && sidebar) {
        sidebar.classList.remove('is-open');
        document.body.classList.remove('sidebar-open');
      }
    });
  });

  if (mobileToggle && sidebar) {
    mobileToggle.addEventListener('click', () => {
      const isOpen = sidebar.classList.toggle('is-open');
      document.body.classList.toggle('sidebar-open', isOpen);
    });
  }

  if (chatInput) {
    chatInput.addEventListener('input', () => {
      updateComposerState();
      autoResizeTextarea();
    });

    chatInput.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        if (!isStreaming) {
          handleSendMessage();
        }
      }
    });
  }

  if (sendBtn) {
    sendBtn.addEventListener('click', handleSendMessage);
  }

  if (clearChatBtn) {
    clearChatBtn.addEventListener('click', renderWelcomeMessage);
  }

  if (pdfFileInput) {
    pdfFileInput.addEventListener('change', (event) => {
      const file = event.target.files?.[0] || null;
      handlePdfSelection(file);
      event.target.value = '';
    });
  }

  if (browsePdfBtn) {
    browsePdfBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      pdfFileInput?.click();
    });
  }

  if (pdfUploadZone) {
    pdfUploadZone.addEventListener('click', () => {
      if (!isAnalyzingPdf) {
        pdfFileInput?.click();
      }
    });

    pdfUploadZone.addEventListener('keydown', (event) => {
      if ((event.key === 'Enter' || event.key === ' ') && !isAnalyzingPdf) {
        event.preventDefault();
        pdfFileInput?.click();
      }
    });

    pdfUploadZone.addEventListener('dragenter', (event) => {
      event.preventDefault();
      event.stopPropagation();
      pdfUploadZone.classList.add('drag-active');
    });

    pdfUploadZone.addEventListener('dragover', (event) => {
      event.preventDefault();
      event.stopPropagation();
      pdfUploadZone.classList.add('drag-active');
    });

    pdfUploadZone.addEventListener('dragleave', (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (!pdfUploadZone.contains(event.relatedTarget)) {
        pdfUploadZone.classList.remove('drag-active');
      }
    });

    pdfUploadZone.addEventListener('drop', (event) => {
      event.preventDefault();
      event.stopPropagation();
      pdfUploadZone.classList.remove('drag-active');
      const droppedFile = event.dataTransfer?.files?.[0] || null;
      handlePdfSelection(droppedFile);
    });
  }

  if (removePdfBtn) {
    removePdfBtn.addEventListener('click', () => {
      clearSelectedFile();
    });
  }

  if (analyzePdfBtn) {
    analyzePdfBtn.addEventListener('click', async () => {
      if (!selectedPdfFile || isAnalyzingPdf) return;

      isAnalyzingPdf = true;
      updateAnalyzeButton();
      clearPdfError();

      if (analysisResult) {
        analysisResult.hidden = false;
      }
      if (analysisBody) {
        analysisBody.innerHTML = `
          <div class="loading-state">
            <div class="loading-spinner"></div>
            <p>Reading scanned PDF and extracting text...</p>
            <p style="font-size: 0.85rem; margin-top: 0.4rem; opacity: 0.7;">This may take a moment for scanned documents.</p>
          </div>
        `;
      }

      try {
        const formData = new FormData();
        formData.append('file', selectedPdfFile);

        const response = await fetch('/api/pdf/analyze', {
          method: 'POST',
          body: formData
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
          throw new Error(errorData.detail || `Analysis failed with status ${response.status}`);
        }

        const data = await response.json();

        if (analysisBody && data.summary) {
          analysisBody.innerHTML = renderMarkdownToHtml(data.summary);
          fetchAndPopulateStats();
        }
      } catch (error) {
        if (analysisBody) {
          analysisBody.innerHTML = `
            <div class="error-state">
              <p><strong>Analysis failed:</strong> ${error.message}</p>
            </div>
          `;
        }
        showPdfError(error.message || 'Failed to analyze PDF');
      } finally {
        isAnalyzingPdf = false;
        updateAnalyzeButton();
      }
    });
  }

  // Quiz Generator elements
  const quizTopicInput = document.getElementById('quizTopicInput');
  const quizDifficultySelect = document.getElementById('quizDifficultySelect');
  const quizCountSelect = document.getElementById('quizCountSelect');
  const generateQuizBtn = document.getElementById('generateQuizBtn');
  const quizSetupCard = document.getElementById('quizSetupCard');
  const quizLoadingCard = document.getElementById('quizLoadingCard');
  const quizLoadingText = document.getElementById('quizLoadingText');
  const quizPlayCard = document.getElementById('quizPlayCard');
  const quizProgressLabel = document.getElementById('quizProgressLabel');
  const quizProgressBar = document.getElementById('quizProgressBar');
  const quizQuestionText = document.getElementById('quizQuestionText');
  const quizOptionsList = document.getElementById('quizOptionsList');
  const quizPrevBtn = document.getElementById('quizPrevBtn');
  const quizNextBtn = document.getElementById('quizNextBtn');
  const quizResultsCard = document.getElementById('quizResultsCard');
  const quizScoreText = document.getElementById('quizScoreText');
  const quizPercentageText = document.getElementById('quizPercentageText');
  const quizPerformanceMessage = document.getElementById('quizPerformanceMessage');
  const quizReviewList = document.getElementById('quizReviewList');
  const quizRestartBtn = document.getElementById('quizRestartBtn');
  const quizError = document.getElementById('quizError');

  // Quiz state
  let quizState = {
    topic: '',
    difficulty: 'Medium',
    count: 5,
    questions: [],
    currentIndex: 0,
    answers: [] // Array of selected option indexes (0-3) or null
  };

  function showQuizError(message) {
    if (!quizError) return;
    quizError.textContent = message;
    quizError.hidden = false;
  }

  function clearQuizError() {
    if (!quizError) return;
    quizError.textContent = '';
    quizError.hidden = true;
  }

  function updateGenerateQuizBtnState() {
    if (!generateQuizBtn || !quizTopicInput) return;
    const isTopicEmpty = quizTopicInput.value.trim() === '';
    generateQuizBtn.disabled = isTopicEmpty;
  }

  if (quizTopicInput) {
    quizTopicInput.addEventListener('input', updateGenerateQuizBtnState);
  }

  function renderCurrentQuizQuestion() {
    if (!quizPlayCard || !quizProgressLabel || !quizProgressBar || !quizQuestionText || !quizOptionsList) return;

    const qIndex = quizState.currentIndex;
    const question = quizState.questions[qIndex];
    const totalQ = quizState.questions.length;

    // Update Progress label and bar
    quizProgressLabel.textContent = `Question ${qIndex + 1} of ${totalQ}`;
    const percent = ((qIndex + 1) / totalQ) * 100;
    quizProgressBar.style.width = `${percent}%`;

    // Render Question Text
    quizQuestionText.textContent = `${qIndex + 1}. ${question.question}`;

    // Render Options
    quizOptionsList.innerHTML = '';
    question.options.forEach((optText, optIdx) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'quiz-option-item';
      if (quizState.answers[qIndex] === optIdx) {
        btn.classList.add('selected');
      }

      btn.innerHTML = `<strong>${String.fromCharCode(65 + optIdx)}.</strong> ${optText}`;
      btn.addEventListener('click', () => {
        // Toggle selected state in state
        quizState.answers[qIndex] = optIdx;
        
        // Highlight active visually
        const siblings = quizOptionsList.querySelectorAll('.quiz-option-item');
        siblings.forEach(s => s.classList.remove('selected'));
        btn.classList.add('selected');
      });
      quizOptionsList.appendChild(btn);
    });

    // Handle button states
    if (quizPrevBtn) {
      quizPrevBtn.disabled = qIndex === 0;
    }

    if (quizNextBtn) {
      if (qIndex === totalQ - 1) {
        quizNextBtn.textContent = 'Submit Quiz';
        quizNextBtn.classList.add('primary');
      } else {
        quizNextBtn.textContent = 'Next';
        quizNextBtn.classList.remove('primary');
      }
    }
  }

  async function handleGenerateQuiz() {
    if (!quizTopicInput || !generateQuizBtn) return;
    const topic = quizTopicInput.value.trim();
    if (!topic) return;

    clearQuizError();

    quizState.topic = topic;
    quizState.difficulty = quizDifficultySelect ? quizDifficultySelect.value : 'Medium';
    quizState.count = quizCountSelect ? parseInt(quizCountSelect.value, 10) : 5;
    quizState.currentIndex = 0;
    quizState.answers = new Array(quizState.count).fill(null);

    // Hide setup, show loader
    if (quizSetupCard) quizSetupCard.hidden = true;
    if (quizLoadingCard) {
      quizLoadingCard.hidden = false;
      if (quizLoadingText) {
        quizLoadingText.textContent = `Generating your quiz on "${topic}"...`;
      }
    }

    try {
      const response = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          topic: topic,
          difficulty: quizState.difficulty,
          question_count: quizState.count
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Unknown quiz generation error' }));
        throw new Error(errorData.detail || `Server error: ${response.status}`);
      }

      const data = await response.json();
      quizState.questions = data.questions;

      if (quizLoadingCard) quizLoadingCard.hidden = true;
      if (quizPlayCard) quizPlayCard.hidden = false;
      renderCurrentQuizQuestion();
    } catch (error) {
      if (quizLoadingCard) quizLoadingCard.hidden = true;
      if (quizSetupCard) quizSetupCard.hidden = false;
      showQuizError(error.message || 'Failed to generate quiz');
    }
  }

  if (generateQuizBtn) {
    generateQuizBtn.addEventListener('click', handleGenerateQuiz);
  }

  if (quizPrevBtn) {
    quizPrevBtn.addEventListener('click', () => {
      if (quizState.currentIndex > 0) {
        quizState.currentIndex--;
        renderCurrentQuizQuestion();
      }
    });
  }

  if (quizNextBtn) {
    quizNextBtn.addEventListener('click', () => {
      const qIndex = quizState.currentIndex;
      const totalQ = quizState.questions.length;

      if (qIndex === totalQ - 1) {
        // Submit Quiz
        handleSubmitQuiz();
      } else {
        quizState.currentIndex++;
        renderCurrentQuizQuestion();
      }
    });
  }

  function handleSubmitQuiz() {
    if (!quizPlayCard || !quizResultsCard || !quizScoreText || !quizPercentageText || !quizPerformanceMessage || !quizReviewList) return;

    let score = 0;
    const total = quizState.questions.length;

    // Calculate score
    quizState.questions.forEach((q, idx) => {
      if (quizState.answers[idx] === q.correct_answer) {
        score++;
      }
    });

    const percent = Math.round((score / total) * 100);

    // Show Results Card, hide Play Card
    quizPlayCard.hidden = true;
    quizResultsCard.hidden = false;

    // Set score texts
    quizScoreText.textContent = `${score} / ${total}`;
    quizPercentageText.textContent = `${percent}%`;

    // Record quiz result if not already recorded
    if (!quizResultRecorded) {
      quizResultRecorded = true;
      fetch('/api/quiz/result', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ percentage: percent })
      })
      .then(res => {
        if (res.ok) {
          fetchAndPopulateStats();
        } else {
          console.error('Failed to record quiz result');
        }
      })
      .catch(err => {
        console.error('Error recording quiz result:', err);
      });
    }

    // Message performance
    let msg = '';
    if (percent >= 90) {
      msg = 'Excellent work!';
    } else if (percent >= 70) {
      msg = 'Great job!';
    } else if (percent >= 50) {
      msg = 'Good effort. Keep practicing!';
    } else {
      msg = 'Keep learning and try again!';
    }
    quizPerformanceMessage.textContent = msg;

    // Render Answer Review list
    quizReviewList.innerHTML = '';
    quizState.questions.forEach((q, idx) => {
      const userAnsIdx = quizState.answers[idx];
      const isCorrect = userAnsIdx === q.correct_answer;

      const item = document.createElement('div');
      item.className = `review-item ${isCorrect ? 'correct' : 'incorrect'}`;

      const questionText = q.question;
      const userAnsText = userAnsIdx !== null ? `${String.fromCharCode(65 + userAnsIdx)}. ${q.options[userAnsIdx]}` : "No Answer Selected";
      const correctAnsText = `${String.fromCharCode(65 + q.correct_answer)}. ${q.options[q.correct_answer]}`;

      item.innerHTML = `
        <p class="review-question"><strong>Q${idx + 1}:</strong> ${questionText}</p>
        <div class="review-answers">
          <div class="review-ans-row user-ans">
            <span class="label">Your Answer:</span>
            <span class="val">${userAnsText}</span>
          </div>
          ${!isCorrect ? `
          <div class="review-ans-row correct-ans">
            <span class="label">Correct Answer:</span>
            <span class="val">${correctAnsText}</span>
          </div>
          ` : ''}
        </div>
      `;
      quizReviewList.appendChild(item);
    });
  }

  function handleRestartQuiz() {
    // Reset state
    quizState = {
      topic: '',
      difficulty: 'Medium',
      count: 5,
      questions: [],
      currentIndex: 0,
      answers: []
    };
    quizResultRecorded = false;

    // Reset inputs
    if (quizTopicInput) {
      quizTopicInput.value = '';
    }
    if (quizDifficultySelect) {
      quizDifficultySelect.value = 'Medium';
    }
    if (quizCountSelect) {
      quizCountSelect.value = '5';
    }

    updateGenerateQuizBtnState();
    clearQuizError();

    // Reset displays
    if (quizSetupCard) quizSetupCard.hidden = false;
    if (quizPlayCard) quizPlayCard.hidden = true;
    if (quizResultsCard) quizResultsCard.hidden = true;
    if (quizReviewList) quizReviewList.innerHTML = '';
  }

  if (quizRestartBtn) {
    quizRestartBtn.addEventListener('click', handleRestartQuiz);
  }


  window.addEventListener('resize', () => {
    if (window.innerWidth > 760 && sidebar) {
      sidebar.classList.remove('is-open');
      document.body.classList.remove('sidebar-open');
    }
  });

  activateSection('dashboard');
  renderWelcomeMessage();
  updateComposerState();
  updateAnalyzeButton();
  fetchAndPopulateStats();
}

document.addEventListener('DOMContentLoaded', initializeApp);

