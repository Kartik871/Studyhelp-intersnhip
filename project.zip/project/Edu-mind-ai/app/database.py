import sqlite3
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("edumind.database")

# Database path in the project root folder
DB_PATH = Path(__file__).resolve().parent.parent / "edumind.db"

def get_connection() -> sqlite3.Connection:
    """Returns a SQLite connection."""
    return sqlite3.connect(DB_PATH)

def initialize_database() -> None:
    """Creates the activity_stats table and initializes the single row with id = 1 if it doesn't exist."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS activity_stats (
                    id INTEGER PRIMARY KEY,
                    questions_asked INTEGER NOT NULL DEFAULT 0,
                    notes_analyzed INTEGER NOT NULL DEFAULT 0,
                    quizzes_taken INTEGER NOT NULL DEFAULT 0,
                    total_quiz_score REAL NOT NULL DEFAULT 0
                )
            """)
            # Ensure row with id=1 exists
            cursor.execute("SELECT id FROM activity_stats WHERE id = 1")
            if cursor.fetchone() is None:
                cursor.execute("""
                    INSERT INTO activity_stats (id, questions_asked, notes_analyzed, quizzes_taken, total_quiz_score)
                    VALUES (1, 0, 0, 0, 0.0)
                """)
            conn.commit()
            logger.info("Database initialized successfully at %s", DB_PATH)
    except Exception as e:
        logger.error("Failed to initialize database: %s", e, exc_info=True)

def increment_questions_asked() -> None:
    """Increments the questions_asked counter by 1."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE activity_stats
                SET questions_asked = questions_asked + 1
                WHERE id = 1
            """)
            conn.commit()
            logger.info("questions_asked incremented successfully")
    except Exception as e:
        logger.error("Failed to increment questions_asked: %s", e, exc_info=True)

def increment_notes_analyzed() -> None:
    """Increments the notes_analyzed counter by 1."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE activity_stats
                SET notes_analyzed = notes_analyzed + 1
                WHERE id = 1
            """)
            conn.commit()
            logger.info("notes_analyzed incremented successfully")
    except Exception as e:
        logger.error("Failed to increment notes_analyzed: %s", e, exc_info=True)

def record_quiz_result(percentage: float) -> None:
    """Increments quizzes_taken by 1 and adds the quiz score to total_quiz_score."""
    if not (0 <= percentage <= 100):
        raise ValueError("Percentage must be between 0 and 100 inclusive")
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE activity_stats
                SET quizzes_taken = quizzes_taken + 1,
                    total_quiz_score = total_quiz_score + ?
                WHERE id = 1
            """, (percentage,))
            conn.commit()
            logger.info("Quiz result recorded successfully: %s%%", percentage)
    except Exception as e:
        logger.error("Failed to record quiz result: %s", e, exc_info=True)

def get_dashboard_stats() -> dict:
    """Fetches the aggregated stats for the dashboard."""
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT questions_asked, notes_analyzed, quizzes_taken, total_quiz_score
                FROM activity_stats
                WHERE id = 1
            """)
            row = cursor.fetchone()
            if row:
                questions_asked, notes_analyzed, quizzes_taken, total_quiz_score = row
                average_score = 0
                if quizzes_taken > 0:
                    average_score = round(total_quiz_score / quizzes_taken)
                return {
                    "questions_asked": questions_asked,
                    "notes_analyzed": notes_analyzed,
                    "quizzes_taken": quizzes_taken,
                    "average_score": average_score
                }
    except Exception as e:
        logger.error("Failed to get dashboard stats: %s", e, exc_info=True)
    
    # Return defaults on failure
    return {
        "questions_asked": 0,
        "notes_analyzed": 0,
        "quizzes_taken": 0,
        "average_score": 0
    }
